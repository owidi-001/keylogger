class Config:
    def __init__(self) -> None:
        pass


    MAIL_SERVER='smtp.gmail.com'
    MAIL_PORT=465 
    MAIL_USERNAME='janna.b335@gmail.com' #Fake mail
    MAIL_PASSWORD='Ecusis4263!!' #Fake password

    # RECEIVER_MAIL="janna.b335@gmail.com"
