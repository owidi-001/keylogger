class Config:
    def __init__(self) -> None:
        pass

    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 465
    MAIL_USERNAME = ''  # Fake mail
    MAIL_PASSWORD = ''  # Fake password
